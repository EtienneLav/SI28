/*jslint */
/*global AdobeEdge: false, window: false, document: false, console:false, alert: false */
(function (compId) {

    "use strict";
    var im='images/',
        aud='media/',
        vid='media/',
        js='js/',
        fonts = {
        },
        opts = {
            'gAudioPreloadPreference': 'auto',
            'gVideoPreloadPreference': 'auto'
        },
        resources = [
        ],
        scripts = [
        ],
        symbols = {
            "stage": {
                version: "6.0.0",
                minimumCompatibleVersion: "5.0.0",
                build: "6.0.0.400",
                scaleToFit: "none",
                centerStage: "none",
                resizeInstances: false,
                content: {
                    dom: [
                        {
                            id: 'fond',
                            type: 'image',
                            rect: ['0', '0', '679px', '538px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"fond.png",'0px','0px']
                        },
                        {
                            id: 'bulle2',
                            type: 'image',
                            rect: ['467px', '21px', '212px', '86px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",im+"bulle2.png",'0px','0px']
                        },
                        {
                            id: 'bonhomme3',
                            type: 'image',
                            rect: ['75px', '294px', '252px', '244px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",im+"bonhomme3.png",'0px','0px']
                        },
                        {
                            id: 'bulle1',
                            type: 'image',
                            rect: ['283px', '155px', '228px', '192px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",im+"bulle1.png",'0px','0px']
                        },
                        {
                            id: 'bonhomme2',
                            type: 'image',
                            rect: ['-287px', '0px', '287px', '540px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"bonhomme2.png",'0px','0px']
                        }
                    ],
                    style: {
                        '${Stage}': {
                            isStage: true,
                            rect: ['null', 'null', '679px', '536px', 'auto', 'auto'],
                            overflow: 'hidden',
                            fill: ["rgba(255,255,255,1)"]
                        }
                    }
                },
                timeline: {
                    duration: 2000,
                    autoPlay: true,
                    data: [
                        [
                            "eid10",
                            "left",
                            0,
                            1000,
                            "linear",
                            "${bonhomme3}",
                            '75px',
                            '128px'
                        ],
                        [
                            "eid9",
                            "opacity",
                            0,
                            1000,
                            "linear",
                            "${bonhomme3}",
                            '0',
                            '1'
                        ],
                        [
                            "eid13",
                            "opacity",
                            0,
                            0,
                            "linear",
                            "${bulle1}",
                            '0',
                            '0'
                        ],
                        [
                            "eid15",
                            "opacity",
                            1000,
                            580,
                            "linear",
                            "${bulle1}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid3",
                            "left",
                            0,
                            1000,
                            "linear",
                            "${bonhomme2}",
                            '-287px',
                            '0px'
                        ],
                        [
                            "eid17",
                            "opacity",
                            1580,
                            420,
                            "linear",
                            "${bulle2}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid11",
                            "top",
                            0,
                            1000,
                            "linear",
                            "${bonhomme3}",
                            '294px',
                            '292px'
                        ],
                        [
                            "eid2",
                            "top",
                            0,
                            0,
                            "linear",
                            "${bonhomme2}",
                            '0px',
                            '0px'
                        ]
                    ]
                }
            }
        };

    AdobeEdge.registerCompositionDefn(compId, symbols, fonts, scripts, resources, opts);

    if (!window.edge_authoring_mode) AdobeEdge.getComposition(compId).load("Sans%20titre-2_edgeActions.js");
})("EDGE-470915441");
