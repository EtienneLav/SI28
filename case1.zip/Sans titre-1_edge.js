/*jslint */
/*global AdobeEdge: false, window: false, document: false, console:false, alert: false */
(function (compId) {

    "use strict";
    var im='images/',
        aud='media/',
        vid='media/',
        js='js/',
        fonts = {
        },
        opts = {
            'gAudioPreloadPreference': 'auto',
            'gVideoPreloadPreference': 'auto'
        },
        resources = [
        ],
        scripts = [
        ],
        symbols = {
            "stage": {
                version: "6.0.0",
                minimumCompatibleVersion: "5.0.0",
                build: "6.0.0.400",
                scaleToFit: "none",
                centerStage: "none",
                resizeInstances: false,
                content: {
                    dom: [
                        {
                            id: 'fond',
                            type: 'image',
                            rect: ['0', '-2px', '678px', '523px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"fond.png",'0px','0px']
                        },
                        {
                            id: 'visage',
                            type: 'image',
                            rect: ['473px', '15px', '291px', '506px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"visage.png",'0px','0px']
                        },
                        {
                            id: 'Sans_titre-3',
                            type: 'image',
                            rect: ['104px', '0', '361px', '293px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",im+"Sans%20titre-3.png",'0px','0px']
                        },
                        {
                            id: 'monsieurmoustache',
                            type: 'image',
                            rect: ['112px', '227px', '333px', '294px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",im+"monsieurmoustache.png",'0px','0px']
                        },
                        {
                            id: 'pouce',
                            type: 'image',
                            rect: ['233px', '521px', '194px', '133px', 'auto', 'auto'],
                            fill: ["rgba(0,0,0,0)",im+"pouce.png",'0px','0px']
                        }
                    ],
                    style: {
                        '${Stage}': {
                            isStage: true,
                            rect: ['null', 'null', '678px', '519px', 'auto', 'auto'],
                            overflow: 'hidden',
                            fill: ["rgba(255,255,255,1)"]
                        }
                    }
                },
                timeline: {
                    duration: 2000,
                    autoPlay: true,
                    data: [
                        [
                            "eid4",
                            "top",
                            0,
                            0,
                            "linear",
                            "${monsieurmoustache}",
                            '227px',
                            '227px'
                        ],
                        [
                            "eid5",
                            "left",
                            0,
                            1000,
                            "linear",
                            "${monsieurmoustache}",
                            '112px',
                            '78px'
                        ],
                        [
                            "eid10",
                            "left",
                            0,
                            1000,
                            "linear",
                            "${visage}",
                            '473px',
                            '387px'
                        ],
                        [
                            "eid2",
                            "opacity",
                            0,
                            1000,
                            "linear",
                            "${monsieurmoustache}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid14",
                            "left",
                            1000,
                            0,
                            "linear",
                            "${pouce}",
                            '233px',
                            '233px'
                        ],
                        [
                            "eid16",
                            "top",
                            1000,
                            1000,
                            "linear",
                            "${pouce}",
                            '521px',
                            '388px'
                        ],
                        [
                            "eid13",
                            "opacity",
                            1000,
                            500,
                            "linear",
                            "${Sans_titre-3}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid11",
                            "top",
                            0,
                            1000,
                            "linear",
                            "${visage}",
                            '70px',
                            '15px'
                        ]
                    ]
                }
            }
        };

    AdobeEdge.registerCompositionDefn(compId, symbols, fonts, scripts, resources, opts);

    if (!window.edge_authoring_mode) AdobeEdge.getComposition(compId).load("Sans%20titre-1_edgeActions.js");
})("EDGE-470297926");
