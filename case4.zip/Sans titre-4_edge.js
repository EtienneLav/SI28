/*jslint */
/*global AdobeEdge: false, window: false, document: false, console:false, alert: false */
(function (compId) {

    "use strict";
    var im='images/',
        aud='media/',
        vid='media/',
        js='js/',
        fonts = {
        },
        opts = {
            'gAudioPreloadPreference': 'auto',
            'gVideoPreloadPreference': 'auto'
        },
        resources = [
        ],
        scripts = [
        ],
        symbols = {
            "stage": {
                version: "6.0.0",
                minimumCompatibleVersion: "5.0.0",
                build: "6.0.0.400",
                scaleToFit: "none",
                centerStage: "none",
                resizeInstances: false,
                content: {
                    dom: [
                        {
                            id: 'fond2',
                            type: 'image',
                            rect: ['0px', '173px', '99px', '351px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",im+"fond2.png",'0px','0px']
                        },
                        {
                            id: 'fond0',
                            type: 'image',
                            rect: ['443px', '8px', '279px', '611px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",im+"fond0.png",'0px','0px']
                        },
                        {
                            id: 'fond12',
                            type: 'image',
                            rect: ['0', '0', '452px', '613px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",im+"fond12.png",'0px','0px']
                        },
                        {
                            id: 'case1',
                            type: 'image',
                            rect: ['81px', '10px', '316px', '113px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",im+"case1.png",'0px','0px']
                        },
                        {
                            id: 'eclab2',
                            type: 'image',
                            rect: ['106px', '196px', '74px', '172px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",im+"eclab2.png",'0px','0px']
                        },
                        {
                            id: 'eclab',
                            type: 'image',
                            rect: ['50px', '269px', '39px', '138px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",im+"eclab.png",'0px','0px']
                        },
                        {
                            id: 'gouttes',
                            type: 'image',
                            rect: ['99px', '213px', '27px', '112px', 'auto', 'auto'],
                            opacity: '0',
                            fill: ["rgba(0,0,0,0)",im+"gouttes.png",'0px','0px']
                        },
                        {
                            id: 'Ellipse',
                            type: 'ellipse',
                            rect: ['496px', '133px', '7px', '6px', 'auto', 'auto'],
                            borderRadius: ["50%", "50%", "50%", "50%"],
                            opacity: '0',
                            fill: ["rgba(255,255,255,1.00)"],
                            stroke: [0,"rgba(0,0,0,1)","none"],
                            boxShadow: ["", 0, 0, 13, 0, "rgba(237,237,237,0.65)"]
                        },
                        {
                            id: 'EllipseCopy2',
                            type: 'ellipse',
                            rect: ['480px', '74px', '7px', '6px', 'auto', 'auto'],
                            borderRadius: ["50%", "50%", "50%", "50%"],
                            opacity: '0',
                            fill: ["rgba(255,255,255,1.00)"],
                            stroke: [0,"rgba(0,0,0,1)","none"],
                            boxShadow: ["", 0, 0, 13, 0, "rgba(237,237,237,0.65)"]
                        },
                        {
                            id: 'EllipseCopy4',
                            type: 'ellipse',
                            rect: ['558px', '56px', '7px', '6px', 'auto', 'auto'],
                            borderRadius: ["50%", "50%", "50%", "50%"],
                            opacity: '0',
                            fill: ["rgba(255,255,255,1.00)"],
                            stroke: [0,"rgba(0,0,0,1)","none"],
                            boxShadow: ["", 0, 0, 13, 0, "rgba(237,237,237,0.65)"]
                        }
                    ],
                    style: {
                        '${Stage}': {
                            isStage: true,
                            rect: ['null', 'null', '723px', '618px', 'auto', 'auto'],
                            overflow: 'hidden',
                            fill: ["rgba(0,0,0,1.00)"]
                        }
                    }
                },
                timeline: {
                    duration: 8890,
                    autoPlay: true,
                    data: [
                        [
                            "eid156",
                            "boxShadow.spread",
                            3980,
                            210,
                            "linear",
                            "${EllipseCopy4}",
                            '0px',
                            '7px'
                        ],
                        [
                            "eid157",
                            "boxShadow.spread",
                            4190,
                            220,
                            "linear",
                            "${EllipseCopy4}",
                            '7px',
                            '0px'
                        ],
                        [
                            "eid158",
                            "boxShadow.spread",
                            4410,
                            210,
                            "linear",
                            "${EllipseCopy4}",
                            '0px',
                            '7px'
                        ],
                        [
                            "eid161",
                            "boxShadow.spread",
                            5050,
                            220,
                            "linear",
                            "${EllipseCopy4}",
                            '7px',
                            '0px'
                        ],
                        [
                            "eid164",
                            "boxShadow.spread",
                            5700,
                            210,
                            "linear",
                            "${EllipseCopy4}",
                            '0px',
                            '7px'
                        ],
                        [
                            "eid165",
                            "boxShadow.spread",
                            5910,
                            220,
                            "linear",
                            "${EllipseCopy4}",
                            '7px',
                            '0px'
                        ],
                        [
                            "eid166",
                            "boxShadow.spread",
                            6675,
                            210,
                            "linear",
                            "${EllipseCopy4}",
                            '0px',
                            '7px'
                        ],
                        [
                            "eid167",
                            "boxShadow.spread",
                            6885,
                            220,
                            "linear",
                            "${EllipseCopy4}",
                            '7px',
                            '0px'
                        ],
                        [
                            "eid168",
                            "boxShadow.spread",
                            7105,
                            210,
                            "linear",
                            "${EllipseCopy4}",
                            '0px',
                            '7px'
                        ],
                        [
                            "eid169",
                            "boxShadow.spread",
                            7315,
                            220,
                            "linear",
                            "${EllipseCopy4}",
                            '7px',
                            '0px'
                        ],
                        [
                            "eid170",
                            "boxShadow.spread",
                            7535,
                            210,
                            "linear",
                            "${EllipseCopy4}",
                            '0px',
                            '7px'
                        ],
                        [
                            "eid171",
                            "boxShadow.spread",
                            7745,
                            220,
                            "linear",
                            "${EllipseCopy4}",
                            '7px',
                            '0px'
                        ],
                        [
                            "eid174",
                            "boxShadow.spread",
                            8395,
                            210,
                            "linear",
                            "${EllipseCopy4}",
                            '0px',
                            '7px'
                        ],
                        [
                            "eid175",
                            "boxShadow.spread",
                            8605,
                            220,
                            "linear",
                            "${EllipseCopy4}",
                            '7px',
                            '0px'
                        ],
                        [
                            "eid13",
                            "opacity",
                            0,
                            500,
                            "linear",
                            "${fond2}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid26",
                            "opacity",
                            3365,
                            545,
                            "linear",
                            "${Ellipse}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid150",
                            "opacity",
                            3910,
                            135,
                            "linear",
                            "${Ellipse}",
                            '1',
                            '0.66666666666667'
                        ],
                        [
                            "eid151",
                            "opacity",
                            4045,
                            2015,
                            "linear",
                            "${Ellipse}",
                            '0.66666666666667',
                            '0.000000'
                        ],
                        [
                            "eid48",
                            "opacity",
                            6060,
                            545,
                            "linear",
                            "${Ellipse}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid11",
                            "opacity",
                            0,
                            0,
                            "linear",
                            "${fond0}",
                            '0',
                            '0'
                        ],
                        [
                            "eid24",
                            "opacity",
                            2750,
                            1250,
                            "linear",
                            "${fond0}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid4",
                            "opacity",
                            0,
                            0,
                            "linear",
                            "${eclab}",
                            '0',
                            '0'
                        ],
                        [
                            "eid22",
                            "opacity",
                            2320,
                            430,
                            "linear",
                            "${eclab}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid2",
                            "opacity",
                            0,
                            0,
                            "linear",
                            "${gouttes}",
                            '0',
                            '0'
                        ],
                        [
                            "eid20",
                            "opacity",
                            2250,
                            70,
                            "linear",
                            "${gouttes}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid6",
                            "opacity",
                            0,
                            0,
                            "linear",
                            "${eclab2}",
                            '0',
                            '0'
                        ],
                        [
                            "eid18",
                            "opacity",
                            2000,
                            250,
                            "linear",
                            "${eclab2}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid10",
                            "opacity",
                            0,
                            0,
                            "linear",
                            "${fond12}",
                            '0',
                            '0'
                        ],
                        [
                            "eid16",
                            "opacity",
                            1000,
                            1000,
                            "linear",
                            "${fond12}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid14",
                            "opacity",
                            0,
                            1000,
                            "linear",
                            "${case1}",
                            '0.000000',
                            '1'
                        ],
                        [
                            "eid28",
                            "boxShadow.spread",
                            3910,
                            210,
                            "linear",
                            "${Ellipse}",
                            '0px',
                            '7px'
                        ],
                        [
                            "eid29",
                            "boxShadow.spread",
                            4120,
                            220,
                            "linear",
                            "${Ellipse}",
                            '7px',
                            '0px'
                        ],
                        [
                            "eid30",
                            "boxShadow.spread",
                            4340,
                            0,
                            "linear",
                            "${Ellipse}",
                            '0px',
                            '0px'
                        ],
                        [
                            "eid31",
                            "boxShadow.spread",
                            4770,
                            0,
                            "linear",
                            "${Ellipse}",
                            '0px',
                            '0px'
                        ],
                        [
                            "eid32",
                            "boxShadow.spread",
                            4770,
                            210,
                            "linear",
                            "${Ellipse}",
                            '0px',
                            '7px'
                        ],
                        [
                            "eid33",
                            "boxShadow.spread",
                            4980,
                            220,
                            "linear",
                            "${Ellipse}",
                            '7px',
                            '0px'
                        ],
                        [
                            "eid34",
                            "boxShadow.spread",
                            5200,
                            0,
                            "linear",
                            "${Ellipse}",
                            '0px',
                            '0px'
                        ],
                        [
                            "eid35",
                            "boxShadow.spread",
                            5630,
                            0,
                            "linear",
                            "${Ellipse}",
                            '0px',
                            '0px'
                        ],
                        [
                            "eid36",
                            "boxShadow.spread",
                            5630,
                            210,
                            "linear",
                            "${Ellipse}",
                            '0px',
                            '7px'
                        ],
                        [
                            "eid37",
                            "boxShadow.spread",
                            5840,
                            220,
                            "linear",
                            "${Ellipse}",
                            '7px',
                            '0px'
                        ],
                        [
                            "eid38",
                            "boxShadow.spread",
                            6605,
                            210,
                            "linear",
                            "${Ellipse}",
                            '0px',
                            '7px'
                        ],
                        [
                            "eid39",
                            "boxShadow.spread",
                            6815,
                            220,
                            "linear",
                            "${Ellipse}",
                            '7px',
                            '0px'
                        ],
                        [
                            "eid40",
                            "boxShadow.spread",
                            7035,
                            210,
                            "linear",
                            "${Ellipse}",
                            '0px',
                            '7px'
                        ],
                        [
                            "eid41",
                            "boxShadow.spread",
                            7245,
                            220,
                            "linear",
                            "${Ellipse}",
                            '7px',
                            '0px'
                        ],
                        [
                            "eid42",
                            "boxShadow.spread",
                            7465,
                            210,
                            "linear",
                            "${Ellipse}",
                            '0px',
                            '7px'
                        ],
                        [
                            "eid43",
                            "boxShadow.spread",
                            7675,
                            220,
                            "linear",
                            "${Ellipse}",
                            '7px',
                            '0px'
                        ],
                        [
                            "eid44",
                            "boxShadow.spread",
                            7895,
                            0,
                            "linear",
                            "${Ellipse}",
                            '0px',
                            '0px'
                        ],
                        [
                            "eid45",
                            "boxShadow.spread",
                            8325,
                            0,
                            "linear",
                            "${Ellipse}",
                            '0px',
                            '0px'
                        ],
                        [
                            "eid46",
                            "boxShadow.spread",
                            8325,
                            210,
                            "linear",
                            "${Ellipse}",
                            '0px',
                            '7px'
                        ],
                        [
                            "eid47",
                            "boxShadow.spread",
                            8535,
                            220,
                            "linear",
                            "${Ellipse}",
                            '7px',
                            '0px'
                        ],
                        [
                            "eid115",
                            "opacity",
                            3500,
                            545,
                            "linear",
                            "${EllipseCopy2}",
                            '0.000000',
                            '0.65185185185185'
                        ],
                        [
                            "eid116",
                            "opacity",
                            6195,
                            545,
                            "linear",
                            "${EllipseCopy2}",
                            '0.65185185185185',
                            '1'
                        ],
                        [
                            "eid95",
                            "boxShadow.spread",
                            4045,
                            210,
                            "linear",
                            "${EllipseCopy2}",
                            '0px',
                            '7px'
                        ],
                        [
                            "eid96",
                            "boxShadow.spread",
                            4255,
                            220,
                            "linear",
                            "${EllipseCopy2}",
                            '7px',
                            '0px'
                        ],
                        [
                            "eid97",
                            "boxShadow.spread",
                            4475,
                            210,
                            "linear",
                            "${EllipseCopy2}",
                            '0px',
                            '7px'
                        ],
                        [
                            "eid98",
                            "boxShadow.spread",
                            4685,
                            0,
                            "linear",
                            "${EllipseCopy2}",
                            '7px',
                            '7px'
                        ],
                        [
                            "eid99",
                            "boxShadow.spread",
                            5115,
                            0,
                            "linear",
                            "${EllipseCopy2}",
                            '7px',
                            '7px'
                        ],
                        [
                            "eid100",
                            "boxShadow.spread",
                            5115,
                            220,
                            "linear",
                            "${EllipseCopy2}",
                            '7px',
                            '0px'
                        ],
                        [
                            "eid101",
                            "boxShadow.spread",
                            5335,
                            0,
                            "linear",
                            "${EllipseCopy2}",
                            '0px',
                            '0px'
                        ],
                        [
                            "eid102",
                            "boxShadow.spread",
                            5765,
                            0,
                            "linear",
                            "${EllipseCopy2}",
                            '0px',
                            '0px'
                        ],
                        [
                            "eid103",
                            "boxShadow.spread",
                            5765,
                            210,
                            "linear",
                            "${EllipseCopy2}",
                            '0px',
                            '7px'
                        ],
                        [
                            "eid104",
                            "boxShadow.spread",
                            5975,
                            220,
                            "linear",
                            "${EllipseCopy2}",
                            '7px',
                            '0px'
                        ],
                        [
                            "eid105",
                            "boxShadow.spread",
                            6740,
                            210,
                            "linear",
                            "${EllipseCopy2}",
                            '0px',
                            '7px'
                        ],
                        [
                            "eid106",
                            "boxShadow.spread",
                            6950,
                            220,
                            "linear",
                            "${EllipseCopy2}",
                            '7px',
                            '0px'
                        ],
                        [
                            "eid107",
                            "boxShadow.spread",
                            7170,
                            210,
                            "linear",
                            "${EllipseCopy2}",
                            '0px',
                            '7px'
                        ],
                        [
                            "eid108",
                            "boxShadow.spread",
                            7380,
                            220,
                            "linear",
                            "${EllipseCopy2}",
                            '7px',
                            '0px'
                        ],
                        [
                            "eid109",
                            "boxShadow.spread",
                            7600,
                            210,
                            "linear",
                            "${EllipseCopy2}",
                            '0px',
                            '7px'
                        ],
                        [
                            "eid110",
                            "boxShadow.spread",
                            7810,
                            220,
                            "linear",
                            "${EllipseCopy2}",
                            '7px',
                            '0px'
                        ],
                        [
                            "eid111",
                            "boxShadow.spread",
                            8030,
                            0,
                            "linear",
                            "${EllipseCopy2}",
                            '0px',
                            '0px'
                        ],
                        [
                            "eid112",
                            "boxShadow.spread",
                            8460,
                            0,
                            "linear",
                            "${EllipseCopy2}",
                            '0px',
                            '0px'
                        ],
                        [
                            "eid113",
                            "boxShadow.spread",
                            8460,
                            210,
                            "linear",
                            "${EllipseCopy2}",
                            '0px',
                            '7px'
                        ],
                        [
                            "eid114",
                            "boxShadow.spread",
                            8670,
                            220,
                            "linear",
                            "${EllipseCopy2}",
                            '7px',
                            '0px'
                        ],
                        [
                            "eid153",
                            "opacity",
                            3435,
                            545,
                            "linear",
                            "${EllipseCopy4}",
                            '0.000000',
                            '0.65185185185185'
                        ],
                        [
                            "eid154",
                            "opacity",
                            6130,
                            545,
                            "linear",
                            "${EllipseCopy4}",
                            '0.65185185185185',
                            '1'
                        ],
                        [
                            "eid120",
                            "top",
                            8755,
                            0,
                            "linear",
                            "${EllipseCopy2}",
                            '74px',
                            '74px'
                        ],
                        [
                            "eid119",
                            "left",
                            8755,
                            0,
                            "linear",
                            "${EllipseCopy2}",
                            '480px',
                            '480px'
                        ]
                    ]
                }
            }
        };

    AdobeEdge.registerCompositionDefn(compId, symbols, fonts, scripts, resources, opts);

    if (!window.edge_authoring_mode) AdobeEdge.getComposition(compId).load("Sans%20titre-4_edgeActions.js");
})("EDGE-473478277");
